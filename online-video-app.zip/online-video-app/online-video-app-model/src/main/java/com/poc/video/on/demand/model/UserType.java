package com.poc.video.on.demand.model;

public enum UserType {
	GOLD, SILVER, BRONZE
}
